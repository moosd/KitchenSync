import com.moosd.kitchensyncd.networking.Networking;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			if(args.length != 2) {
				System.err.println("Usage:\n\tkitchensend type message");
				System.exit(1);
			}
			
			final Networking net = new Networking("TESTEST123");
			//net.directSend.dump("192.168.1.", 10000, 2, "test".getBytes());
			
			net.directSend.dump(10000, Integer.parseInt(args[0]), (args[1]).getBytes());
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
}
