package com.moosd.kitchensyncd.sync;


public class RealTimeSync {


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
	}

}
